//
//  UserInformation.h
//  CaseStudyAbhi
//
//  Created by Mavericks on 21/04/16.
//  Copyright (c) 2016 abhi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserInformation : NSObject

@property (nonatomic)int Id;
@property (nonatomic) NSString *repositoryName;
@property (nonatomic)NSString *ownerName;
@property (nonatomic)NSString *ownerAvtar;

@property (nonatomic)NSString *ownerNameOnly;




@end
