//
//  RepositoryListViewController.h
//  CaseStudyAbhi
//
//  Created by Mavericks on 20/04/16.
//  Copyright (c) 2016 abhi. All rights reserved.
//

#import "BaseViewController.h"
@class UserInformation;

@interface RepositoryListViewController : BaseViewController <UITableViewDataSource,UITableViewDelegate,NSURLConnectionDataDelegate>
{
    UserInformation *userDetails;
    NSString *tempData;
    
    NSMutableArray *repositories;
    NSMutableArray *avatarImageArray;

}
@property (nonatomic)int repositoryID;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
