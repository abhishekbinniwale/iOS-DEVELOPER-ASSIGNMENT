//
//  RepositoryListViewController.m
//  CaseStudyAbhi
//
//  Created by Mavericks on 20/04/16.
//  Copyright (c) 2016 abhi. All rights reserved.
//

#import "RepositoryListViewController.h"

#import "UserInformation.h"
#import "Constants.h"
#import "Utils.h"
#import "UIImageView+WebCache.h"
#import "DetailsRepositoryViewController.h"

//http://api.github.com/repositories

@interface RepositoryListViewController ()

@end

@implementation RepositoryListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=@"List Of Repositories";
    
    self.tableView.dataSource=self;
    self.tableView.delegate=self;
    
    repositories=[[NSMutableArray alloc]init];
    avatarImageArray= [[NSMutableArray alloc]init];
    
    [self fetchRepository];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)fetchRepository{
    NSString *strUrl=[Utils getURL:REPOSITORY_URL];
    [self makeServerCallWithUrl:strUrl];


}

-(void)parseResult:(NSData *)data               //To do JSON parse
{
    NSArray *tempRepository=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    
    for (NSDictionary *dictionary in tempRepository)
    {        
        UserInformation *userInfo=[[UserInformation alloc]init];
        userInfo.Id=[[dictionary valueForKey:@"id"] intValue];
        userInfo.repositoryName=[dictionary valueForKey:@"name"];
        userInfo.ownerName=[dictionary valueForKey:@"full_name"];
       
        NSDictionary *avatarImages = [dictionary valueForKey:@"owner"];
        
        userInfo.ownerAvtar = [avatarImages valueForKey:@"avatar_url"];
        
        [repositories addObject:userInfo];

    }
    [self.tableView reloadData];
}

#pragma mark - tableView  methods

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [repositories count];

}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell=[self.tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
    }
    
    UserInformation *userInfo=nil;
    userInfo=[repositories objectAtIndex:indexPath.row];
    
    
    cell.textLabel.text=userInfo.repositoryName;
    cell.detailTextLabel.text=userInfo.ownerName;
    
    //Image dwnload by lazy loading
    NSString *strUrl = [NSString stringWithFormat:@"%@", userInfo.ownerAvtar];
    [cell.imageView sd_setImageWithURL:[NSURL URLWithString:strUrl]
                             placeholderImage:[UIImage imageNamed:@"wait_please.gif"] options:SDWebImageRefreshCached|SDWebImageRetryFailed ];

    
    
//    UIImage *image = [self getImageFromServerWithUrl: strUrl];
//    cell.imageView.image= image;
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;

    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    DetailsRepositoryViewController *vc = (DetailsRepositoryViewController *)  [Utils instantiateViewControllerWithId:@"DetailsVC"];
    
    UserInformation *userInfo=nil;
   userInfo = [repositories objectAtIndex:indexPath.row];
   vc.fullName = userInfo.ownerName;
    
    [self.navigationController pushViewController:vc animated:YES];
}


@end
