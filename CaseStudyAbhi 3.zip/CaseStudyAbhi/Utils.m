//
//  Utils.m
//  CaseStudyAbhi
//
//  Created by Mavericks on 20/04/16.
//  Copyright (c) 2016 abhi. All rights reserved.
//


#import "Constants.h"
#import "Utils.h"
#import <UIKit/UIKit.h>
@implementation Utils

+ (void)showAlert:(NSString *)message {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

+ (NSString *)getURL:(NSString *)page {
    return [NSString stringWithFormat:@"%@/%@", SERVER_URL, page];
}

+ (UIViewController *)instantiateViewControllerWithId:(NSString *)vcId {
    return [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:vcId];
}

@end
