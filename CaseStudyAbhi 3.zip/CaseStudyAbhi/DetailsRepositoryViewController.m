//
//  DetailsRepositoryViewController.m
//  CaseStudyAbhi
//
//  Created by admin on 22/04/16.
//  Copyright © 2016 abhi. All rights reserved.
//

#import "DetailsRepositoryViewController.h"
#import "UserInformation.h"
#import "Constants.h"
#import "Utils.h"
#import "UIImageView+WebCache.h"


//https://api.github.com/repos/mojombo/grit

@interface DetailsRepositoryViewController ()

@end

@implementation DetailsRepositoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=self.fullName;
    
    ownerRepos=[[NSMutableArray alloc]init];
   
    [self fetchOwner];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)fetchOwner{
    NSString *strUrl=[NSString stringWithFormat:@"%@%@",[Utils getURL:REPOSITORY_DETAILS_URL],self.fullName];
    [self makeServerCallWithUrl:strUrl];
    
    
}

-(void)parseResult:(NSData *)data               //To Parse result
{
    NSDictionary *dictionary=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
  
        UserInformation *userInfo=[[UserInformation alloc]init];
        
        userInfo.repositoryName=[dictionary valueForKey:@"name"];
        userInfo.ownerName=[dictionary valueForKey:@"full_name"];
    
        NSDictionary *avatarImages = [dictionary valueForKey:@"owner"];
    userInfo.ownerNameOnly = [avatarImages valueForKey:@"login"];
        userInfo.ownerAvtar = [avatarImages valueForKey:@"avatar_url"];
    
    self.repoName.text = userInfo.repositoryName;
    self.repoOwnerName.text = userInfo.ownerName;
    self.ownerName.text = userInfo.ownerNameOnly;
    
    
    //Image dwnload by lazy loading 
    NSString *strUrl = [NSString stringWithFormat:@"%@", userInfo.ownerAvtar];
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:strUrl]
                      placeholderImage:[UIImage imageNamed:@"wait_please.gif"] options:SDWebImageRefreshCached|SDWebImageRetryFailed ];
    
    
}


@end
