//
//  Constants.h
//  CaseStudyAbhi
//
//  Created by Mavericks on 20/04/16.
//  Copyright (c) 2016 abhi. All rights reserved.
//

#ifndef CaseStudyAbhi_Constants_h
#define CaseStudyAbhi_Constants_h

#define SERVER_URL @"https://api.github.com"
#define REPOSITORY_URL @"repositories"
#define REPOSITORY_DETAILS_URL @"repos/"



#endif
