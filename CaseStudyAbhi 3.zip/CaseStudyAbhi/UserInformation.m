//
//  UserInformation.m
//  CaseStudyAbhi
//
//  Created by Mavericks on 21/04/16.
//  Copyright (c) 2016 abhi. All rights reserved.
//

#import "UserInformation.h"

@implementation UserInformation

@end
