//
//  BaseViewController.h
//  CaseStudyAbhi
//
//  Created by Mavericks on 20/04/16.
//  Copyright (c) 2016 abhi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController{

    NSMutableData *container;
    NSURLConnection *connection;

}

-(void)makeServerCallWithUrl:(NSString *)strUrl;
-(void)parseResult:(NSData *)data;
-(UIImage*)getImageFromServerWithUrl:(NSString*)strUrl;
@end
