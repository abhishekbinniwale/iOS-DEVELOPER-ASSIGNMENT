//
//  BaseViewController.m
//  CaseStudyAbhi
//
//  Created by Mavericks on 20/04/16.
//  Copyright (c) 2016 abhi. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)makeServerCallWithUrl:(NSString *)strUrl                 //To make call to the server to fetch data
{
    container=[[NSMutableData alloc]init];                      //container to append data which id=s collected from                            server
    
    NSURL *url=[NSURL URLWithString:strUrl];
    
    NSURLRequest *request=[NSURLRequest requestWithURL:url];        //Make request to the server
    
    connection =[NSURLConnection connectionWithRequest:request delegate:self];
    
    [connection start];                                         //To start connection with server for data
}




#pragma mark    -urlconnection Method

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {        //To receive data from server append into container
    [container appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {                      //To give data for parsing to parseResult
    [self parseResult:container];
}

-(void)parseResult:(NSData *)data{
    
    NSLog(@"Parse result in baseViewController");           //TO parse result taken from server by JSON parsing
    
    
}
-(UIImage*)getImageFromServerWithUrl:(NSString*)strUrl
{
    NSURL *url = [NSURL URLWithString:strUrl];
    NSData *data = [NSData dataWithContentsOfURL:url];
    UIImage *image = [UIImage imageWithData:data];
    return image;
}



@end
