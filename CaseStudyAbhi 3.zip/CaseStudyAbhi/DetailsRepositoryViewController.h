//
//  DetailsRepositoryViewController.h
//  CaseStudyAbhi
//
//  Created by admin on 22/04/16.
//  Copyright © 2016 abhi. All rights reserved.
//

#import "BaseViewController.h"

@interface DetailsRepositoryViewController : BaseViewController<NSURLConnectionDataDelegate>{

    NSMutableArray *ownerRepos;

}

@property (nonatomic) NSString *fullName;

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *repoName;
@property (weak, nonatomic) IBOutlet UILabel *repoOwnerName;
@property (weak, nonatomic) IBOutlet UILabel *ownerName;

@end
